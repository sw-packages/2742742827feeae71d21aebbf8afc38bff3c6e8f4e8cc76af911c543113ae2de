
Supersingular Isogeny Key Encapsulation  (SIKE)
================================================

The code in this directory is taken from the MIT Licensed SIKE optimized portable implementation submitted to NIST here:
https://csrc.nist.gov/CSRC/media/Projects/Post-Quantum-Cryptography/documents/round-1/submissions/SIKE.zip

Only minor modifications were made in order to integrate this code into s2n's build system.